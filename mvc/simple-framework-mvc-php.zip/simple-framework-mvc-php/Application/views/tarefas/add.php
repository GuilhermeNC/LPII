<main>
    <div class="container">
        <div class="col-8 offset-2" style="margin-top:100px">
        <h2>Adicionar Tarefas</h2>
            <form action="/tarefa/add" method="POST">
                <label for="desc">Descricao:</label><br>
                <input type="text" id="desc" name="desc" placeholder="Insira a descrição aqui" autofocus>
                <input type="submit" name="Adicinar">
            </form>
        </div>
    </div>
</main>
