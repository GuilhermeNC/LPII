<nav>
    <a href="/home/">Home</a> |
    <a href="/user/">Usuários</a> |
    <a href="/tarefa/">Tarefas</a> |
    <a href="/tarefa/formulario">Adicionar</a>
</nav>
